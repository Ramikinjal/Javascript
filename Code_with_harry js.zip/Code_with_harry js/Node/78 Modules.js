// const { hello, ahello } = require("./Modules1"); // commonjs
import harry, { hello, ahello } from "./Modules2.js";
hello();
ahello("kevil");
ahello("jenish");
ahello("kevil kalathiya");
harry();

// ES6 Modules
export const hello = () => {
  console.log("Hello harry");
};

export const ahello = (name) => {
  console.log("Hello " + name);
};

const harry = () => {
  console.log("Hello harry2");
};

export default harry;
